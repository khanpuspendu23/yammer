package com.cg;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xslf.usermodel.XSLFSheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Content {

    public static void main(String[] args) throws InterruptedException, IOException {

        System.setProperty("webdriver.chrome.driver","C:\\Users\\PUKHAN\\Downloads\\selenium\\selenium\\Driver\\chromedriver.exe" );

        WebDriver driver = new ChromeDriver();
        driver.get("https://web.yammer.com/main/org/capgemini.com");

        String dataForPost = null;

        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        driver.findElement(By.xpath("//*[@id=\"i0116\"]")).sendKeys("puspendu.khan@capgemini.com");
        driver.findElement(By.xpath("//*[@id=\"idSIButton9\"]")).click();

        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.xpath("//*[@id=\"KmsiCheckboxField\"]")).click();

        Thread.sleep(11000);
        driver.findElement(By.id("idSIButton9")).click();

        driver.findElement(By.linkText("Automation practice group")).click();
        //driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[1]/div/div/div/div[1]/div[2]/div/div/div/div/nav/div[2]/div/div/div[1]/div[2]/div/div/div/div[2]/ul/li[2]/div/div/div/div/a/div/div/div[2]/div/div/div/div")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        String ExcelFile = "./data/Book1.xlsx";
        XSSFWorkbook workbook = new XSSFWorkbook(ExcelFile);

        XSSFSheet sheet = workbook.getSheet("Sheet1");
       //count no. of rows 
        int rowCount = sheet.getPhysicalNumberOfRows();
     //   System.out.println("No of rows: " +rowCount);


        //to get data
        for(int i=0; i<rowCount ; i++) {
     //   Row row = sheet.getRow(i);

        for (int j = 0; j < rowCount; j++) {
            WebElement content1=driver.findElement(By.xpath("//div[contains(text(),'Share thoughts, ideas, or updates')]"));
            //WebElement content1=driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/div/div[1]/div/div/div[2]/div[1]/div/div/div[1]/div/div/div/div/div/div/div/div[2]/div/button/div/div"));
            content1.click();

            dataForPost =sheet.getRow(j).getCell(0).getStringCellValue().toString();
            //for periodic post of content
            WebElement postContent= driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/div/div/div/div/div[2]/div[1]/div/div/div/div/div/div[3]/div/div/span/div/div[2]/div/div/div/div/span"));
            postContent.sendKeys(dataForPost);

            //for posting
            Thread.sleep(3000);
            driver.findElement(By.xpath("//*[@id=\"root\"]/div/div[2]/div/div[2]/div/div/div/div/div/div[2]/div[1]/div/div/div/div/div/div[5]/div[2]/div/ul/li/div/div/button")).click();

            Thread.sleep(10000);

            driver.navigate().refresh();

            TimeUnit.SECONDS.sleep(20);
        }
    }
    workbook.close();
        }
     }